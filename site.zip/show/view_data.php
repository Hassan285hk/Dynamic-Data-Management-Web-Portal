<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mydatabase";

// Create connection
include 'db.php';

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$unit = isset($_GET['unit']) ? $_GET['unit'] : 'unit1';
$action = isset($_GET['action']) ? $_GET['action'] : 'legal';
$table = $action . '_' . $unit;

if (!isset($_SESSION['deleted_rows'])) {
    $_SESSION['deleted_rows'] = [];
}

// Function to delete a row
if (isset($_POST['delete']) && isset($_POST['id']) && isset($_POST['table'])) {
    $id = $_POST['id'];
    if (!isset($_SESSION['deleted_rows'][$table])) {
        $_SESSION['deleted_rows'][$table] = [];
    }
    $_SESSION['deleted_rows'][$table][] = $id;
}

// Function to save deletions
if (isset($_POST['save'])) {
    foreach ($_SESSION['deleted_rows'] as $table => $ids) {
        foreach ($ids as $id) {
            $stmt = $conn->prepare("DELETE FROM $table WHERE id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $stmt->close();
        }
    }
    $_SESSION['deleted_rows'] = [];
}

// Fetch data from the selected table
function fetchData($conn, $table) {
    $sql = "SELECT * FROM $table";
    return $conn->query($sql);
}

$data = fetchData($conn, $table);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Data</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <style>
        body {
            background-color: #e9f7ef;
            color: #2c3e50;
        }
        .container {
            margin-top: 50px;
        }
        .table-responsive {
            margin-top: 30px;
        }
        .btn-delete {
            background-color: #dc3545;
            border: none;
            color: white;
        }
        .btn-delete:hover {
            background-color: #c82333;
        }
        .btn-save {
            margin-top: 20px;
            background-color: #28a745;
            border: none;
        }
        .navbar {
            background-color: #388e3c;
            color: white;
        }
        .navbar a {
            color: white;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light">
        <a class="navbar-brand" href="#"><?php echo ucfirst($unit);?> Data</a>
        <div class="collapse navbar-collapse">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item">
                    <a class="nav-link" href="view_data.php?unit=<?php echo $unit; ?>&action=legal">Legal</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="view_data.php?unit=<?php echo $unit; ?>&action=illegal">Illegal</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="view_data.php?unit=<?php echo $unit; ?>&action=changing">Changing</a>
                </li>
            </ul>
            <a href="unit_home.php?unit=<?php echo $unit; ?>" class="btn btn-light">Back</a>
        </div>
    </nav>
    <div class="container">
        <h2>Data for <?php echo ucfirst($action) . ' ' . ucfirst($unit); ?></h2>
        <div class="table-responsive">
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Father's Name</th>
                        <th>CNIC</th>
                        <th>Mobile No</th>
                        <th>Fees</th>
                        <th>Address</th>
                        <th>Computer No</th>
                        <th>Card No</th>
                        <th>Date of Issue</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $data->fetch_assoc()): ?>
                        <?php if (!in_array($row['id'], $_SESSION['deleted_rows'][$table] ?? [])): ?>
                            <tr>
                                <td><?php echo $row['name']; ?></td>
                                <td><?php echo $row['father_name']; ?></td>
                                <td><?php echo $row['cnic']; ?></td>
                                <td><?php echo $row['mobile_no']; ?></td>
                                <td><?php echo $row['fees']; ?></td>
                                <td><?php echo $row['address']; ?></td>
                                <td><?php echo $row['computer_no']; ?></td>
                                <td><?php echo $row['card_no']; ?></td>
                                <td><?php echo $row['date_of_issue']; ?></td>
                                <td>
                                    <form method="post" action="view_data.php?unit=<?php echo $unit; ?>&action=<?php echo $action; ?>">
                                        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                                        <input type="hidden" name="table" value="<?php echo $table; ?>">
                                        <button type="submit" name="delete" class="btn btn-delete">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endif; ?>
                    <?php endwhile; ?>
                </tbody>
            </table>
            <form method="post" action="view_data.php?unit=<?php echo $unit; ?>&action=<?php echo $action; ?>">
                <button type="submit" name="save" class="btn btn-save">Save</button>
            </form>
        </div>
    </div>
</body>
</html>

<?php $conn->close(); ?>
