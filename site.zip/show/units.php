<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Units</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <style>
        body {
            background-color: #e9f7ef;
            color: #2c3e50;
        }
        .container {
            margin-top: 50px;
        }
        .btn-unit {
            margin: 10px;
        }
        .navbar {
            background-color: #388e3c;
            color: white;
        }
        .navbar a {
            color: white;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light">
        <a class="navbar-brand" href="#">Units</a>
    </nav>
    <div class="container text-center">
        <h2>Select a Unit</h2>
        <?php for ($i = 1; $i <= 11; $i++): ?>
            <a href="unit_home.php?unit=unit<?php echo $i; ?>" class="btn btn-success btn-unit">Unit <?php echo $i; ?></a>
        <?php endfor; ?>
    </div>
</body>
</html>
