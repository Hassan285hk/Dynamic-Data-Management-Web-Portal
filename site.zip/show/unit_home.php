<?php
session_start();
if (!isset($_SESSION['email'])) {
    header("Location: index.php");
    exit();
}

if (isset($_GET['unit'])) {
    $unit = $_GET['unit'];
} else {
    die("Unit parameter is missing.");
}

// Array of unit incharge names
$unit_incharges = [
    'unit1' => 'Main Unit',
    'unit2' => 'Asif Yousfi',
    'unit3' => 'Muhammad Azam',
    'unit4' => 'Mian Arshad',
    'unit5' => 'Muhammad Riaz',
    'unit6' => 'Haji Afzal',
    'unit7' => 'Mian Mansha',
    'unit8' => 'Abdul Shakur',
    'unit9' => 'Mehar Mustafa',
    'unit10' => 'Mian Irfan',
    'unit11' => 'Hafiz Zaheer'
];

// Get the incharge name for the current unit
$unit_incharge = $unit_incharges[$unit];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Unit Home</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <style>
        body {
            background-color: #e9f7ef;
            color: #2c3e50;
        }
        .container {
            margin-top: 50px;
        }
        .navbar {
            background-color: #388e3c;
            color: white;
        }
        .navbar a {
            color: white;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light">
        <a class="navbar-brand" href="#"><?php echo ucfirst($unit_incharge); echo "-->"; echo $unit;?></a>
        <div class="collapse navbar-collapse">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item">
                    <a class="nav-link" href="view_data.php?unit=<?php echo $unit; ?>&action=legal">Legal</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="view_data.php?unit=<?php echo $unit; ?>&action=illegal">Illegal</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="view_data.php?unit=<?php echo $unit; ?>&action=changing">Changing</a>
                </li>
            </ul>
            <a href="units.php" class="btn btn-light">Back</a>
        </div>
    </nav>
    <div class="container">
        <h2><?php echo ucfirst($unit);  echo "-->";?><?php echo ucfirst($unit_incharge); ?></h2>
        <p><b>Welcome to the home page of <?php echo ucfirst($unit); ?>.</p>
        <p>Unit Incharge: <?php echo $unit_incharge; ?></p></b>
    </div>
</body>
</html>
