<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mydatabase";

// Create connection
include 'db.php';

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $unit = $_POST['unit'];
    $name = $_POST['name'];
    $father_name = $_POST['father_name'];
    $cnic = $_POST['cnic'];
    $mobile_no = $_POST['mobile_no'];
    $fees = $_POST['fees'];
    $address = $_POST['address'];
    $computer_no = $_POST['computer_no'];
    $card_no = $_POST['card_no'];
    $date_of_issue = $_POST['date_of_issue'];

    // Sanitize and verify that the $unit is a valid table name
    $allowed_units = ['unit1', 'unit2', 'unit3', 'unit4', 'unit5', 'unit6', 'unit7', 'unit8', 'unit9', 'unit10', 'unit11'];
    if (in_array($unit, $allowed_units)) {
        // Prepare and bind the SQL statement
        $stmt = $conn->prepare("INSERT INTO $unit (name, father_name, cnic, mobile_no, fees, address, computer_no, card_no, date_of_issue) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssssssss", $name, $father_name, $cnic, $mobile_no, $fees, $address, $computer_no, $card_no, $date_of_issue);

        if ($stmt->execute() === TRUE) {
            echo "Data saved successfully. <a href='save_data.php'>Enter more data</a>";
        } else {
            echo "Error: " . $stmt->error;
        }

        $stmt->close();
    } else {
        echo "Invalid unit selection.";
    }
} else {
    echo "Unit selection is missing.";
}

$conn->close();
?>
