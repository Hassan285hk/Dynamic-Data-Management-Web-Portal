<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Save Data</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <style>
        body {
            background-color: #e9f7ef;
            color: #2c3e50;
            transition: background-color 0.3s, color 0.3s;
        }
        .container {
            margin-top: 50px;
        }
        .form-container {
            display: flex;
            justify-content: space-between;
        }
        .form-group-half {
            width: 48%;
        }
        .message-box {
            display: none;
            margin-bottom: 20px;
            padding: 10px;
            border: 1px solid #28a745;
            background-color: #d4edda;
            color: #155724;
        }
        .btn-success {
            background-color: #28a745;
            border: none;
        }
        .btn-success:hover {
            background-color: #218838;
        }

        /* Dark Mode Styles */
        .dark-mode {
            background-color: #2c3e50;
            color: #ffffff;
        }
        .dark-mode .form-control {
            background-color: #34495e;
            color: white;
            border: 1px solid #ffffff;
        }
        .dark-mode .form-control::placeholder {
            color: #bbb;
        }
        .dark-mode .btn-primary {
            background-color: #1abc9c;
            border: none;
        }
        .dark-mode .btn-primary:hover {
            background-color: #16a085;
        }
        .dark-mode .message-box {
            background-color: #34495e;
            border: 1px solid #1abc9c;
            color: #1abc9c;
        }
    </style>
</head>
<body>
    <div class="container">
        <button class="btn btn-secondary mb-3" id="themeToggle">Toggle Theme</button>
        <div id="messageBox" class="message-box">Data inserted successfully. <button onclick="resetForm()">OK</button></div>
        <h2>Save Data</h2>
        <form id="dataForm" action="insert_data.php" method="post">
            <div class="form-container">
                <div class="form-group form-group-half">
                    <label for="unit">Unit:</label>
                    <select class="form-control" id="unit" name="unit" required>
                        <option value="unit1">Unit 1</option>
                        <option value="unit2">Unit 2</option>
                        <option value="unit3">Unit 3</option>
                        <option value="unit4">Unit 4</option>
                        <option value="unit5">Unit 5</option>
                        <option value="unit6">Unit 6</option>
                        <option value="unit7">Unit 7</option>
                        <option value="unit8">Unit 8</option>
                        <option value="unit9">Unit 9</option>
                        <option value="unit10">Unit 10</option>
                        <option value="unit11">Unit 11</option>
                    </select>
                </div>
                <div class="form-group form-group-half">
                    <label for="name">Name:</label>
                    <input type="text" class="form-control" id="name" name="name" required>
                </div>
            </div>
            <div class="form-container">
                <div class="form-group form-group-half">
                    <label for="father_name">Father's Name:</label>
                    <input type="text" class="form-control" id="father_name" name="father_name" required>
                </div>
                <div class="form-group form-group-half">
                    <label for="cnic">CNIC:</label>
                    <input type="text" class="form-control" id="cnic" name="cnic" required>
                </div>
            </div>
            <div class="form-container">
                <div class="form-group form-group-half">
                    <label for="mobile_no">Mobile No:</label>
                    <input type="text" class="form-control" id="mobile_no" name="mobile_no" required>
                </div>
                <div class="form-group form-group-half">
                    <label for="fees">Fees:</label>
                    <input type="text" class="form-control" id="fees" name="fees" required>
                </div>
            </div>
            <div class="form-container">
                <div class="form-group form-group-half">
                    <label for="address">Address:</label>
                    <input type="text" class="form-control" id="address" name="address" required>
                </div>
                <div class="form-group form-group-half">
                    <label for="computer_no">Computer Number:</label>
                    <input type="text" class="form-control" id="computer_no" name="computer_no" required>
                </div>
            </div>
            <div class="form-container">
                <div class="form-group form-group-half">
                    <label for="card_no">Card Number:</label>
                    <input type="text" class="form-control" id="card_no" name="card_no" required>
                </div>
                <div class="form-group form-group-half">
                    <label for="date_of_issue">Date of Issue:</label>
                    <input type="date" class="form-control" id="date_of_issue" name="date_of_issue" required>
                </div>
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>

    <script>
        // Function to save selected unit to localStorage
        document.getElementById('unit').addEventListener('change', function() {
            localStorage.setItem('selectedUnit', this.value);
        });

        // Function to load selected unit from localStorage on page load
        window.onload = function() {
            let savedUnit = localStorage.getItem('selectedUnit');
            if (savedUnit) {
                document.getElementById('unit').value = savedUnit;
            }

            // Load the saved theme
            let savedTheme = localStorage.getItem('theme');
            if (savedTheme === 'dark') {
                document.body.classList.add('dark-mode');
            }
        };

        // Theme Toggle Button Functionality
        document.getElementById('themeToggle').addEventListener('click', function() {
            document.body.classList.toggle('dark-mode');
            let theme = document.body.classList.contains('dark-mode') ? 'dark' : 'light';
            localStorage.setItem('theme', theme);
        });

        document.getElementById('dataForm').addEventListener('submit', function(event) {
            event.preventDefault(); // Prevent default form submission

            var xhr = new XMLHttpRequest();
            xhr.open("POST", "insert_data.php", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

            xhr.onreadystatechange = function () {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    document.getElementById('messageBox').style.display = 'block';
                    document.getElementById('dataForm').reset();
                    
                    // Restore last selected unit
                    let savedUnit = localStorage.getItem('selectedUnit');
                    if (savedUnit) {
                        document.getElementById('unit').value = savedUnit;
                    }
                }
            };

            var formData = new FormData(document.getElementById('dataForm'));
            xhr.send(new URLSearchParams(formData).toString());
        });

        function resetForm() {
            document.getElementById('messageBox').style.display = 'none';
        }
    </script>
</body>
</html>
