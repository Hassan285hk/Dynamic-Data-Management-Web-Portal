<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mydatabase";

// Create connection
include 'db.php';

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $card_no = $_POST['card_no'];
    $computer_no = $_POST['computer_no'];

    // Use prepared statements to insert data into the 'moeez' table
    $stmt = $conn->prepare("INSERT INTO moeez (card_no, computer_no) VALUES (?, ?)");
    $stmt->bind_param("ss", $card_no, $computer_no); // 'ss' specifies that both parameters are strings
    if ($stmt->execute()) {
        echo "Data inserted successfully!";
    } else {
        echo "Error: " . $stmt->error;
    }
    $stmt->close();
}

$conn->close();
?>
